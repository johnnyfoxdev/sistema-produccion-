import {
  Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn,
} from 'typeorm';

@Entity('reportes')
export default class Reporte {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({
    type: 'varchar',
    length: '130',
  })
  responsable: string;

  @Column()
  nombre_curso: string;

  @Column()
  nombre_recurso: string;

  @Column()
  numero_slides: number;

  @Column()
  tipo_recurso: string;

  @Column({
    type: 'date',
  })
  fecha: string;

  @CreateDateColumn()
  created_at: string;

  @UpdateDateColumn()
  updated_at: string;
}
