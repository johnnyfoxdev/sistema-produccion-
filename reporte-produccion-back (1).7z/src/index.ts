/* eslint-disable @typescript-eslint/no-namespace */
import express, { Application } from 'express';
import dotenv from 'dotenv';
import bodyParser from 'body-parser';
import routesV1 from './routes/v1';
import conexion from './utils/Conexion';

dotenv.config();
declare global{
  namespace Express{
    export interface Request{
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      sessionData: any;
    }
  }
}
const app: Application = express();

//Definicion APP
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Authorization, X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Allow-Request-Method, token');
  res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
  res.header('Allow', 'GET, POST, OPTIONS, PUT, DELETE');
  next();
});
routesV1(app);
const port = process.env.PORT || 4000;
conexion.getConnection().then(con => {
  console.log(con.isConnected);
  app.listen(port, () => {
    console.log('Servidor escuchando en', port);
  });
}).catch(err => console.log(err));
