/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable @typescript-eslint/no-unused-vars */
import { Request, Response } from 'express';
import { Connection, getConnection } from 'typeorm';
import json2xls from 'json2xls';
import fs from 'fs';
import Reporte from '../models/Report';

let con: Connection;

const createReporte = async (req: Request, res: Response): Promise<void> => {
  try {
    con = getConnection();
    const reportManager = con.getRepository(Reporte);
    const reporte = new Reporte();
    reporte.responsable = req.body.responsable;
    reporte.nombre_curso = req.body.nombre_curso;
    reporte.nombre_recurso = req.body.nombre_recurso;
    reporte.tipo_recurso = req.body.tipo_recurso;
    reporte.numero_slides = req.body.numero_slides;
    reporte.fecha = req.body.fecha;
    const resporteSaved = await reportManager.save(reporte);
    res.status(201).json({ status: 'OK', message: `Reporte creado con el ID ${resporteSaved.id}` });
  } catch (error) {
    res.status(500).json({ status: 'ERROR', message: error.message });
  }
};

const getReportes = async (req: Request, res: Response): Promise<void> => {
  try {
    con = getConnection();
    const reportes = await con.getRepository(Reporte).createQueryBuilder('rp')
      .select('rp.responsable', 'Responsable')
      .addSelect('rp.nombre_curso', 'Nombre Curso')
      .addSelect('rp.nombre_recurso', 'Nombre Recurso')
      .addSelect('rp.numero_slides', 'Numero Slides')
      .addSelect('rp.tipo_recurso', 'Tipo Recurso')
      .addSelect('rp.fecha', 'Fecha')
      .where('strftime("%W", "now") = strftime("%W", rp.created_at)')
      .getRawMany();
    const xls = json2xls(reportes);
    await fs.promises.writeFile('reporte.xls', xls, 'binary');
    // res.status(200).json({ status: 'OK', message: reportes });
    res.status(200).download('reporte.xls');
  } catch (error) {
    res.status(500).json({ status: 'ERROR', message: error.message });
  }
};

export default { createReporte, getReportes };
