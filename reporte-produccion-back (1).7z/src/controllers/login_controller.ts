import { Request, Response } from 'express';
import jwt from 'jsonwebtoken';

const login = async (req: Request, res: Response): Promise<void> => {
  try {
    const users = {
      jalex: 'jalex666',
      theboss: 'imtheboss',
    };
    const { user, pass } = req.body;
    if (users[user] === pass) {
      const token = jwt.sign({ user }, process.env.JWT_SECRET);
      res.status(200).json({ status: 'OK', message: token });
    } else {
      res.status(401).json({ status: 'UNAUTHORIZED', message: 'INCORRECT USER OR PASSWORD' });
    }
  } catch (error) {
    res.status(500).json({ status: 'ERROR', message: error.message });
  }
};

export default { login };
