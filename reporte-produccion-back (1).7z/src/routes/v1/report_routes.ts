import express, { Router } from 'express';
import reportController from '../../controllers/report_controller';
import auth from '../../middelwares/Auth';

const router: Router = express.Router();

router.get('/', auth.isAuth, reportController.getReportes);
router.post('/create', reportController.createReporte);

export default router;
