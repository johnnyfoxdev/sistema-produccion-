import { Application, Response, Request } from 'express';
import reportRoutes from './report_routes';
import login from '../../controllers/login_controller';

export default (app: Application): void => {
  app.use('/reportes', reportRoutes);
  app.post('/login', login.login);
  app.use('/', (req: Request, res: Response) => {
    res.status(200).json({ status: 'OK', message: 'Home de API' });
  });
};
