import { Connection, ConnectionOptions, createConnection } from 'typeorm';
import Reporte from '../models/Report';

const options: ConnectionOptions = {
  type: 'sqlite',
  database: 'report_db.sqlite',
  entities: [
    Reporte,
  ],
};

const getConnection = async (): Promise<Connection> => {
  try {
    const con = await createConnection(options);
    con.synchronize(true);
    return con;
  } catch (error) {
    throw new Error('Conexion fallida');
  }
};

export default { getConnection };
